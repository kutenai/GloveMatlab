function quatvec = qmat2vec(quatmat)
%
% converts quaternion 4x4 matrix to quaternion 4-vector
%
quatvec = quatmat(:,1);